"""
Script to process GDU Google Reviews from CSV file and display/analyze the data.
This script reads CSV data with Google Reviews format and provides functionality to work with review data.
"""

import csv
import json
import ast
from datetime import datetime
from typing import List, Dict, Any
import os

def parse_user_data(user_string: str) -> Dict[str, Any]:
    """
    Parse user data from dictionary string format
    """
    try:
        user_dict = ast.literal_eval(user_string)
        return {
            'name': user_dict.get('name', 'Anonymous'),
            'thumbnail': user_dict.get('thumbnail', ''),
            'link': user_dict.get('link', ''),
            'local_guide': user_dict.get('local_guide', False),
            'reviews_count': user_dict.get('reviews', 0)
        }
    except:
        return {
            'name': 'Anonymous',
            'thumbnail': '',
            'link': '',
            'local_guide': False,
            'reviews_count': 0
        }

def read_reviews_from_csv(csv_file_path: str) -> List[Dict[str, Any]]:
    """
    Read Google Reviews data from CSV file
    
    Expected CSV columns:
    - user: User dictionary string (name, thumbnail, link, etc.)
    - rating: Rating (1-5)
    - date: Review date in Vietnamese relative format
    - snippet: Review text/comment
    """
    reviews = []
    
    try:
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            csv_reader = csv.DictReader(file)
            
            for row in csv_reader:
                user_data = parse_user_data(row.get('user', '{}'))
                
                rating = float(row.get('rating', 0))
                
                review = {
                    'id': len(reviews) + 1,
                    'name': user_data['name'],
                    'avatar': user_data['thumbnail'],
                    'rating': rating,
                    'comment': row.get('snippet', ''),
                    'date': row.get('date', ''),
                    'verified': True,  # All Google reviews are verified
                    'isLocalGuide': user_data['local_guide'],
                    'reviewsCount': user_data['reviews_count']
                }
                reviews.append(review)
        
        print(f"✓ Successfully loaded {len(reviews)} Google reviews from CSV")
        return reviews
        
    except FileNotFoundError:
        print(f"✗ Error: CSV file not found at {csv_file_path}")
        return []
    except Exception as e:
        print(f"✗ Error reading CSV: {str(e)}")
        return []

def calculate_statistics(reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate statistics from reviews data"""
    if not reviews:
        return {
            'total_reviews': 0,
            'average_rating': 0,
            'rating_distribution': {}
        }
    
    total_reviews = len(reviews)
    total_rating = sum(review['rating'] for review in reviews)
    average_rating = round(total_rating / total_reviews, 2)
    
    # Rating distribution
    rating_distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for review in reviews:
        rating = int(review['rating'])
        if rating in rating_distribution:
            rating_distribution[rating] += 1
    
    # Local guide count
    local_guide_count = sum(1 for r in reviews if r.get('isLocalGuide', False))
    
    stats = {
        'total_reviews': total_reviews,
        'average_rating': average_rating,
        'rating_distribution': rating_distribution,
        'verified_count': total_reviews,  # All Google reviews are verified
        'local_guide_count': local_guide_count
    }
    
    return stats

def export_to_json(data: Any, output_path: str):
    """Export data to JSON file"""
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
        print(f"✓ Successfully exported to {output_path}")
    except Exception as e:
        print(f"✗ Error exporting to JSON: {str(e)}")

def main():
    # Set the path to your CSV file
    csv_file_path = 'data/reviews.csv'
    
    # Read reviews from CSV
    reviews = read_reviews_from_csv(csv_file_path)
    
    if reviews:
        # Calculate statistics
        stats = calculate_statistics(reviews)
        
        print("\n=== GDU Google Reviews Statistics ===")
        print(f"Total Reviews: {stats['total_reviews']}")
        print(f"Average Rating: {stats['average_rating']}/5.0")
        print(f"Verified Reviews: {stats['verified_count']}")
        print(f"Local Guide Reviews: {stats['local_guide_count']}")
        
        print("\nRating Distribution:")
        for rating in range(5, 0, -1):
            count = stats['rating_distribution'][rating]
            percentage = (count / stats['total_reviews'] * 100) if stats['total_reviews'] > 0 else 0
            bar = '█' * int(percentage / 2)
            print(f"  {rating} ⭐: {bar} {count} ({percentage:.1f}%)")
        
        # Export to JSON for API usage
        output_json = 'public/data/reviews.json'
        export_to_json(reviews, output_json)
        
        # Also export statistics
        stats_json = 'public/data/reviews-stats.json'
        export_to_json(stats, stats_json)
        
        print("\n✓ Google Reviews data successfully processed and ready for display!")
    else:
        print("\nNo reviews found. Please check your CSV file.")
        print(f"Expected CSV path: {csv_file_path}")
        print("\nCreate a CSV file with these columns:")
        print("user,rating,date,snippet")

if __name__ == "__main__":
    main()
