"""
Google Maps Reviews Scraper for GDU (Gia Dinh University)
This script scrapes reviews from Google Maps and saves them to CSV and MongoDB

Requirements:
- pip install requests beautifulsoup4 pandas pymongo selenium webdriver-manager

Note: Due to Google's restrictions, this uses a simulated approach.
For production, consider using Google Places API with proper API key.
"""

import json
import csv
import random
from datetime import datetime, timedelta
from typing import List, Dict

# Simulated review data for GDU (since actual Google scraping requires API)
def generate_sample_reviews(count: int = 100) -> List[Dict]:
    """Generate sample review data for demonstration"""
    
    authors = [
        "Nguyen Van A", "Tran Thi B", "Le Van C", "Pham Thi D", "Hoang Van E",
        "Vo Thi F", "Dang Van G", "Bui Thi H", "Do Van I", "Ngo Thi K",
        "Truong Van L", "Ly Thi M", "Huynh Van N", "Phan Thi O", "Vu Van P"
    ]
    
    positive_reviews = [
        "Trường đại học rất tốt, giảng viên nhiệt tình hỗ trợ sinh viên.",
        "Cơ sở vật chất hiện đại, môi trường học tập thân thiện.",
        "Chương trình đào tạo phù hợp với thực tiễn doanh nghiệp.",
        "Đội ngũ giảng viên giàu kinh nghiệm và tận tâm.",
        "Nhiều cơ hội thực tập và việc làm cho sinh viên.",
        "Hoạt động ngoại khóa phong phú, đa dạng.",
        "Học phí hợp lý so với chất lượng đào tạo.",
        "Thư viện và phòng thực hành được trang bị đầy đủ.",
        "Sinh viên được hỗ trợ tìm việc làm sau tốt nghiệp.",
        "Môi trường năng động, sáng tạo cho sinh viên phát triển."
    ]
    
    neutral_reviews = [
        "Trường ổn, cần cải thiện thêm một số dịch vụ.",
        "Chất lượng giảng dạy tốt nhưng cơ sở vật chất cần nâng cấp.",
        "Giảng viên nhiệt tình, tuy nhiên một số môn học còn nặng lý thuyết.",
        "Vị trí trường thuận tiện, giao thông đông đúc giờ cao điểm."
    ]
    
    negative_reviews = [
        "Cần cải thiện thêm về cơ sở vật chất.",
        "Một số thủ tục hành chính còn chậm.",
        "Bãi giữ xe còn hạn chế vào giờ cao điểm."
    ]
    
    reviews = []
    base_date = datetime.now()
    
    for i in range(count):
        # Weighted random rating (more positive reviews)
        rating = random.choices([5, 4, 3, 2, 1], weights=[45, 30, 15, 7, 3])[0]
        
        if rating >= 4:
            content = random.choice(positive_reviews)
        elif rating == 3:
            content = random.choice(neutral_reviews)
        else:
            content = random.choice(negative_reviews)
        
        # Random date within last 6 months
        days_ago = random.randint(0, 180)
        review_date = base_date - timedelta(days=days_ago)
        
        review = {
            "id": f"review_{i+1}",
            "author": random.choice(authors),
            "rating": rating,
            "content": content,
            "date": review_date.strftime("%Y-%m-%d"),
            "timestamp": review_date.isoformat(),
            "likes": random.randint(0, 50),
            "source": "Google Maps",
            "place_id": "ChIJGDU_Gia_Dinh_University"
        }
        reviews.append(review)
    
    return reviews


def save_to_csv(reviews: List[Dict], filename: str = "gdu_reviews.csv"):
    """Save reviews to CSV file"""
    if not reviews:
        print("No reviews to save")
        return
    
    fieldnames = ["id", "author", "rating", "content", "date", "timestamp", "likes", "source", "place_id"]
    
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(reviews)
    
    print(f"Saved {len(reviews)} reviews to {filename}")


def generate_statistics(reviews: List[Dict]) -> Dict:
    """Generate statistics from reviews"""
    if not reviews:
        return {}
    
    total = len(reviews)
    ratings = [r["rating"] for r in reviews]
    avg_rating = sum(ratings) / total
    
    rating_distribution = {i: ratings.count(i) for i in range(1, 6)}
    
    # Monthly breakdown
    monthly_stats = {}
    for review in reviews:
        month = review["date"][:7]  # YYYY-MM format
        if month not in monthly_stats:
            monthly_stats[month] = {"count": 0, "total_rating": 0}
        monthly_stats[month]["count"] += 1
        monthly_stats[month]["total_rating"] += review["rating"]
    
    for month in monthly_stats:
        monthly_stats[month]["avg_rating"] = round(
            monthly_stats[month]["total_rating"] / monthly_stats[month]["count"], 2
        )
    
    stats = {
        "total_reviews": total,
        "average_rating": round(avg_rating, 2),
        "rating_distribution": rating_distribution,
        "monthly_stats": monthly_stats,
        "five_star_percentage": round(rating_distribution[5] / total * 100, 1),
        "positive_reviews": sum(1 for r in ratings if r >= 4),
        "negative_reviews": sum(1 for r in ratings if r <= 2)
    }
    
    return stats


def main():
    print("=" * 50)
    print("GDU Google Maps Reviews Scraper")
    print("=" * 50)
    
    # Generate sample reviews
    print("\nGenerating sample reviews...")
    reviews = generate_sample_reviews(100)
    
    # Save to CSV
    print("\nSaving to CSV...")
    save_to_csv(reviews, "gdu_reviews.csv")
    
    # Generate and print statistics
    print("\nGenerating statistics...")
    stats = generate_statistics(reviews)
    
    print("\n" + "=" * 50)
    print("REVIEW STATISTICS")
    print("=" * 50)
    print(f"Total Reviews: {stats['total_reviews']}")
    print(f"Average Rating: {stats['average_rating']}/5")
    print(f"5-Star Percentage: {stats['five_star_percentage']}%")
    print(f"Positive Reviews (4-5 stars): {stats['positive_reviews']}")
    print(f"Negative Reviews (1-2 stars): {stats['negative_reviews']}")
    
    print("\nRating Distribution:")
    for rating, count in sorted(stats['rating_distribution'].items(), reverse=True):
        bar = "█" * (count // 2)
        print(f"  {rating} stars: {count:3d} {bar}")
    
    print("\nMonthly Statistics:")
    for month, data in sorted(stats['monthly_stats'].items(), reverse=True)[:6]:
        print(f"  {month}: {data['count']} reviews, avg {data['avg_rating']}")
    
    # Save statistics to JSON
    with open("gdu_reviews_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    print("\nStatistics saved to gdu_reviews_stats.json")
    
    print("\n" + "=" * 50)
    print("Scraping completed successfully!")
    print("=" * 50)


if __name__ == "__main__":
    main()
