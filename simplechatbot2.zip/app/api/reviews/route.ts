import { NextResponse } from "next/server"
import { readFileSync, existsSync } from "fs"
import { join } from "path"

function getAvatarColor(name: string): string {
  const colors = [
    "from-blue-500 to-blue-600",
    "from-purple-500 to-purple-600",
    "from-pink-500 to-pink-600",
    "from-green-500 to-green-600",
    "from-yellow-500 to-yellow-600",
    "from-red-500 to-red-600",
    "from-indigo-500 to-indigo-600",
    "from-teal-500 to-teal-600",
    "from-orange-500 to-orange-600",
    "from-cyan-500 to-cyan-600",
  ]
  const index = name.charCodeAt(0) % colors.length
  return colors[index]
}

function loadReviewsFromJSON() {
  try {
    const dataPath = join(process.cwd(), "public", "data", "reviews.json")
    if (existsSync(dataPath)) {
      const fileContent = readFileSync(dataPath, "utf-8")
      const csvReviews = JSON.parse(fileContent)

      if (!csvReviews || csvReviews.length === 0) {
        return null
      }

      return csvReviews.map((review: any) => {
        const nameParts = review.name.trim().split(" ")
        const avatar =
          nameParts.length >= 2
            ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
            : review.name.substring(0, 2).toUpperCase()

        const reviewDate = new Date(review.date)
        let year = "K2023" // Default
        if (review.department && review.department.includes("K20")) {
          year = review.department.match(/K20\d{2}/)?.[0] || "K2023"
        } else if (reviewDate.getFullYear() >= 2020 && reviewDate.getFullYear() <= 2025) {
          year = `K${reviewDate.getFullYear() - 4}`
        }

        return {
          id: String(review.id),
          author: review.name,
          avatar: avatar,
          avatarColor: getAvatarColor(review.name),
          major: review.department,
          year: year,
          rating: review.rating,
          category: mapDepartmentToCategory(review.department),
          title: generateTitle(review.comment, review.rating),
          content: review.comment,
          likes: 0,
          comments: 0,
          date: reviewDate.toLocaleDateString("vi-VN"),
          helpful: review.verified === "True" || review.verified === true,
        }
      })
    }
  } catch (error) {
    console.error("[v0] Error loading CSV reviews:", error)
  }
  return null
}

function generateTitle(comment: string, rating: number): string {
  if (!comment || comment.trim().length === 0) {
    return rating >= 4 ? "Trải nghiệm tốt" : rating === 3 ? "Trải nghiệm khá" : "Cần cải thiện"
  }

  if (comment.length <= 50) return comment

  const firstSentence = comment.split(/[.!?]/)[0].trim()
  if (firstSentence.length > 0 && firstSentence.length <= 60) {
    return firstSentence
  }

  return comment.substring(0, 50) + "..."
}

function mapDepartmentToCategory(department: string): string {
  const mapping: Record<string, string> = {
    "Công nghệ thông tin": "Chương trình đào tạo",
    "Kinh tế": "Chương trình đào tạo",
    "Quản trị kinh doanh": "Hỗ trợ việc làm",
    Marketing: "Hoạt động sinh viên",
    General: "Khác",
  }
  return mapping[department] || "Chương trình đào tạo"
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")

    const csvReviews = loadReviewsFromJSON()

    if (!csvReviews || csvReviews.length === 0) {
      return NextResponse.json({
        success: true,
        reviews: [],
        total: 0,
        source: "none",
        message: "Chưa có dữ liệu. Vui lòng xử lý file CSV.",
      })
    }

    let filteredReviews = csvReviews

    if (category && category !== "Tất cả") {
      filteredReviews = csvReviews.filter((r) => r.category === category)
    }

    return NextResponse.json({
      success: true,
      reviews: filteredReviews,
      total: filteredReviews.length,
      source: "csv",
    })
  } catch (error) {
    console.error("[v0] Error fetching reviews:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch reviews",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const newReview = {
      id: String(Date.now()),
      author: "Người dùng mới",
      avatar: "ND",
      avatarColor: "from-primary to-secondary",
      major: "Sinh viên GDU",
      year: "2024",
      rating: body.rating || 5,
      category: body.category || "Khác",
      title: body.title || "Đánh giá mới",
      content: body.content || "",
      likes: 0,
      comments: 0,
      date: new Date().toLocaleDateString("vi-VN"),
      helpful: false,
    }

    console.log("[v0] New review created:", newReview)

    return NextResponse.json({
      success: true,
      message: "Đánh giá đã được gửi thành công!",
      review: newReview,
    })
  } catch (error) {
    console.error("[v0] Error submitting review:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to submit review",
      },
      { status: 500 },
    )
  }
}
