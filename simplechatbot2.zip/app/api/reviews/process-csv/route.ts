import { NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"
import { join } from "path"

const execAsync = promisify(exec)

export async function POST(request: Request) {
  try {
    // Run the Python script to process CSV
    const scriptPath = join(process.cwd(), "scripts", "process_reviews_csv.py")
    const { stdout, stderr } = await execAsync(`python3 ${scriptPath}`)

    console.log("[v0] Python script output:", stdout)
    if (stderr) {
      console.error("[v0] Python script errors:", stderr)
    }

    return NextResponse.json({
      success: true,
      message: "CSV data processed successfully",
      output: stdout,
    })
  } catch (error: any) {
    console.error("[v0] Error processing CSV:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Failed to process CSV",
      },
      { status: 500 },
    )
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    message: "Use POST method to process CSV data",
    endpoints: {
      process: "POST /api/reviews/process-csv",
      reviews: "GET /api/reviews",
    },
  })
}
