import { NextResponse } from "next/server"

// Mock data - in production this would come from MongoDB
const mockSavedJobs = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "FPT Software",
    logo: "/fpt-software-logo.jpg",
    location: "Quận 7, TP.HCM",
    type: "internship",
    salary: "5-8 triệu",
    deadline: "30/12/2025",
    savedAt: new Date().toISOString(),
  },
  {
    id: "2",
    title: "Marketing Executive",
    company: "Vingroup",
    logo: "/vingroup-logo.jpg",
    location: "Quận 1, TP.HCM",
    type: "full-time",
    salary: "10-15 triệu",
    deadline: "25/12/2025",
    savedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "3",
    title: "Business Analyst",
    company: "Techcombank",
    logo: "/techcombank-logo.jpg",
    location: "Quận 3, TP.HCM",
    type: "full-time",
    salary: "15-20 triệu",
    deadline: "28/12/2025",
    savedAt: new Date(Date.now() - 172800000).toISOString(),
  },
]

export async function GET() {
  try {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    return NextResponse.json({
      success: true,
      data: mockSavedJobs,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch saved jobs" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const jobId = searchParams.get("id")

    if (!jobId) {
      return NextResponse.json({ success: false, error: "Job ID is required" }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      message: "Job removed from saved list",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to remove job" }, { status: 500 })
  }
}
