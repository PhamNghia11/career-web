import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Demo user accounts for testing
    const demoUsers = [
      {
        id: "1",
        email: "admin@gdu.edu.vn",
        password: "admin123",
        name: "Admin GDU",
        role: "admin",
        avatar: "/admin-interface.png",
      },
      {
        id: "2",
        email: "student@gdu.edu.vn",
        password: "student123",
        name: "Nguyễn Văn A",
        role: "student",
        avatar: "/diverse-students-studying.png",
        studentId: "GDU2024001",
        major: "Công nghệ thông tin",
      },
      {
        id: "3",
        email: "employer@company.com",
        password: "employer123",
        name: "Công ty ABC",
        role: "employer",
        avatar: "/diverse-company-team.png",
      },
    ]

    // Find user by email and password
    const user = demoUsers.find((u) => u.email === email && u.password === password)

    if (!user) {
      return NextResponse.json({ error: "Email hoặc mật khẩu không đúng" }, { status: 401 })
    }

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Có lỗi xảy ra. Vui lòng thử lại." }, { status: 500 })
  }
}
