import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, password, phone, role, studentId, major } = body

    // Validate required fields
    if (!name || !email || !password) {
      return NextResponse.json({ error: "Vui lòng điền đầy đủ thông tin" }, { status: 400 })
    }

    // Check if email already exists (in a real app, this would check the database)
    const existingEmails = ["admin@gdu.edu.vn", "student@gdu.edu.vn", "employer@company.com"]

    if (existingEmails.includes(email)) {
      return NextResponse.json({ error: "Email đã được sử dụng" }, { status: 409 })
    }

    // Create new user
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      role: role || "student",
      phone: phone || "",
      avatar: `/placeholder.svg?height=100&width=100&query=${encodeURIComponent(name)}`,
      ...(role === "student" && {
        studentId: studentId || "",
        major: major || "",
      }),
      createdAt: new Date().toISOString(),
    }

    // In a real app, you would save to database here

    return NextResponse.json({
      success: true,
      user: newUser,
    })
  } catch (error) {
    console.error("Register error:", error)
    return NextResponse.json({ error: "Có lỗi xảy ra. Vui lòng thử lại." }, { status: 500 })
  }
}
