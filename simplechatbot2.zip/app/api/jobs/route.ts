import { NextResponse } from "next/server"

const mockJobs = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "FPT Software",
    location: "Quận 7, TP.HCM",
    type: "internship",
    salary: "5-8 triệu",
    description: "Tuyển thực tập sinh Frontend Developer làm việc với React, TypeScript",
    requirements: ["Kiến thức HTML/CSS/JavaScript", "Biết React hoặc Vue", "Sinh viên năm 3-4"],
    benefits: ["Lương thực tập cạnh tranh", "Cơ hội fulltime", "Đào tạo bài bản"],
    deadline: "2025-12-30",
    createdAt: "2025-12-01",
    status: "active",
    applicants: 45,
  },
  {
    id: "2",
    title: "Marketing Executive",
    company: "Vingroup",
    location: "Quận 1, TP.HCM",
    type: "full-time",
    salary: "10-15 triệu",
    description: "Tuyển nhân viên Marketing phụ trách Digital Marketing",
    requirements: ["Tốt nghiệp chuyên ngành Marketing", "1 năm kinh nghiệm", "Thành thạo các công cụ analytics"],
    benefits: ["Lương tháng 13", "Bảo hiểm cao cấp", "Team building hàng tháng"],
    deadline: "2025-12-25",
    createdAt: "2025-11-28",
    status: "active",
    applicants: 78,
  },
]

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const type = searchParams.get("type")
    const status = searchParams.get("status")

    let filteredJobs = mockJobs

    if (type && type !== "all") {
      filteredJobs = filteredJobs.filter((j) => j.type === type)
    }

    if (status && status !== "all") {
      filteredJobs = filteredJobs.filter((j) => j.status === status)
    }

    return NextResponse.json({
      success: true,
      data: {
        jobs: filteredJobs,
        total: filteredJobs.length,
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch jobs" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const newJob = {
      id: String(Date.now()),
      ...body,
      createdAt: new Date().toISOString(),
      status: "active",
      applicants: 0,
    }

    return NextResponse.json({
      success: true,
      message: "Job posted successfully",
      data: newJob,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to post job" }, { status: 500 })
  }
}
