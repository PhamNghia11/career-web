import { NextResponse } from "next/server"

const mockApplications = [
  {
    id: "1",
    jobTitle: "Frontend Developer Intern",
    company: "FPT Software",
    companyLogo: "/fpt-software-logo.jpg",
    appliedDate: new Date().toISOString(),
    status: "reviewing" as const,
    jobLocation: "Quận 7, TP.HCM",
    salary: "5-8 triệu",
  },
  {
    id: "2",
    jobTitle: "Marketing Executive",
    company: "Vingroup",
    companyLogo: "/vingroup-logo.jpg",
    appliedDate: new Date(Date.now() - 86400000).toISOString(),
    status: "interview" as const,
    jobLocation: "Quận 1, TP.HCM",
    salary: "10-15 triệu",
  },
  {
    id: "3",
    jobTitle: "Business Analyst",
    company: "Techcombank",
    companyLogo: "/techcombank-logo.jpg",
    appliedDate: new Date(Date.now() - 259200000).toISOString(),
    status: "pending" as const,
    jobLocation: "Quận 3, TP.HCM",
    salary: "15-20 triệu",
  },
  {
    id: "4",
    jobTitle: "Graphic Designer",
    company: "VNG Corporation",
    companyLogo: "/vng-logo.jpg",
    appliedDate: new Date(Date.now() - 432000000).toISOString(),
    status: "accepted" as const,
    jobLocation: "Quận Tân Bình, TP.HCM",
    salary: "8-12 triệu",
  },
]

export async function GET() {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500))

    return NextResponse.json({
      success: true,
      data: mockApplications,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch applications" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const applicationId = searchParams.get("id")

    if (!applicationId) {
      return NextResponse.json({ success: false, error: "Application ID is required" }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      message: "Application withdrawn successfully",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to withdraw application" }, { status: 500 })
  }
}
