import { NextResponse } from "next/server"

// Mock company data - in production, this would come from a database
const companies = [
  {
    id: "1",
    name: "FPT Software",
    logo: "/fpt-software-logo-black-square.jpg",
    industry: "Công nghệ thông tin",
    size: "10,000+ nhân viên",
    location: "Hồ Chí Minh, Hà Nội",
    description: "Công ty phần mềm hàng đầu Việt Nam, chuyên về phát triển phần mềm và dịch vụ IT",
    openPositions: 45,
    rating: 4.5,
    verified: true,
    benefits: ["Bảo hiểm sức khỏe", "Thưởng hiệu suất", "Đào tạo", "Du lịch hàng năm"],
  },
  {
    id: "2",
    name: "Viettel Group",
    logo: "/viettel-telecommunications-company-logo.jpg",
    industry: "Viễn thông",
    size: "10,000+ nhân viên",
    location: "Toàn quốc",
    description: "Tập đoàn viễn thông và công nghệ số hàng đầu Việt Nam",
    openPositions: 32,
    rating: 4.7,
    verified: true,
    benefits: ["Lương cao", "Cơ hội thăng tiến", "Môi trường quốc tế"],
  },
  {
    id: "3",
    name: "Shopee Vietnam",
    logo: "/shopee-e-commerce-orange-logo.jpg",
    industry: "Thương mại điện tử",
    size: "1,000 - 5,000 nhân viên",
    location: "Hồ Chí Minh",
    description: "Sàn thương mại điện tử hàng đầu khu vực Đông Nam Á",
    openPositions: 28,
    rating: 4.3,
    verified: true,
    benefits: ["Văn hóa trẻ trung", "Team building", "Phụ cấp ăn trưa"],
  },
  {
    id: "4",
    name: "Grab Vietnam",
    logo: "/grab-ride-hailing-green-logo.jpg",
    industry: "Công nghệ - Vận tải",
    size: "500 - 1,000 nhân viên",
    location: "Hồ Chí Minh, Hà Nội",
    description: "Nền tảng công nghệ đa dịch vụ hàng đầu Đông Nam Á",
    openPositions: 19,
    rating: 4.4,
    verified: true,
    benefits: ["Flexible working", "Stock options", "Free Grab rides"],
  },
  {
    id: "5",
    name: "VNG Corporation",
    logo: "/vng-gaming-technology-company-logo.jpg",
    industry: "Game & Technology",
    size: "1,000 - 5,000 nhân viên",
    location: "Hồ Chí Minh",
    description: "Công ty công nghệ và trò chơi điện tử hàng đầu Việt Nam",
    openPositions: 24,
    rating: 4.6,
    verified: true,
    benefits: ["Lương cạnh tranh", "Game room", "Flexible hours"],
  },
  {
    id: "6",
    name: "Tiki Corporation",
    logo: "/tiki-e-commerce-blue-logo.jpg",
    industry: "E-commerce",
    size: "500 - 1,000 nhân viên",
    location: "Hồ Chí Minh, Hà Nội",
    description: "Sàn thương mại điện tử hàng đầu Việt Nam",
    openPositions: 15,
    rating: 4.2,
    verified: true,
    benefits: ["Discount vouchers", "Health insurance", "Learning budget"],
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const search = searchParams.get("search")?.toLowerCase() || ""
  const industry = searchParams.get("industry") || ""
  const size = searchParams.get("size") || ""

  let filtered = companies

  if (search) {
    filtered = filtered.filter(
      (company) =>
        company.name.toLowerCase().includes(search) ||
        company.industry.toLowerCase().includes(search) ||
        company.description.toLowerCase().includes(search),
    )
  }

  if (industry) {
    filtered = filtered.filter((company) => company.industry === industry)
  }

  if (size) {
    filtered = filtered.filter((company) => company.size === size)
  }

  return NextResponse.json({ companies: filtered, total: filtered.length })
}
