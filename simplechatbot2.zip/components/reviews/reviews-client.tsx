"use client"

import { useState, useEffect } from "react"
import { Star, ThumbsUp, MessageSquare, Calendar, TrendingUp, AlertCircle, CheckCircle, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { CSVDataManager } from "./csv-data-manager"

interface Review {
  id: string
  author: string
  avatar: string
  avatarColor?: string
  major: string
  year: string
  rating: number
  category: string
  title: string
  content: string
  likes: number
  comments: number
  date: string
  helpful: boolean
}

export function ReviewsClient() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("Tất cả")
  const [submitting, setSubmitting] = useState(false)
  const [dataSource, setDataSource] = useState<string>("none")
  const [stats, setStats] = useState<any>(null)
  const { toast } = useToast()
  const [newReview, setNewReview] = useState({
    rating: 5,
    category: "Chương trình đào tạo",
    title: "",
    content: "",
  })

  useEffect(() => {
    fetchReviews()
    fetchStats()
  }, [selectedCategory])

  const fetchReviews = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (selectedCategory !== "Tất cả") {
        params.append("category", selectedCategory)
      }
      const response = await fetch(`/api/reviews?${params}`)
      const data = await response.json()
      if (data.success) {
        setReviews(data.reviews)
        setDataSource(data.source || "none")
      }
    } catch (error) {
      console.error("[v0] Failed to fetch reviews:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải đánh giá. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/reviews/stats")
      const data = await response.json()
      if (data.success) {
        setStats(data.stats)
      }
    } catch (error) {
      console.error("[v0] Failed to fetch stats:", error)
    }
  }

  const handleSubmitReview = async () => {
    if (!newReview.title.trim() || !newReview.content.trim()) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng điền đầy đủ tiêu đề và nội dung đánh giá.",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newReview),
      })
      const data = await response.json()
      if (data.success) {
        toast({
          title: "Thành công!",
          description: "Đánh giá của bạn đã được gửi thành công.",
        })
        setShowForm(false)
        setNewReview({ rating: 5, category: "Chương trình đào tạo", title: "", content: "" })
        fetchReviews()
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      console.error("[v0] Failed to submit review:", error)
      toast({
        title: "Lỗi",
        description: "Không thể gửi đánh giá. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleLike = (reviewId: string) => {
    setReviews((prevReviews) =>
      prevReviews.map((review) => (review.id === reviewId ? { ...review, likes: review.likes + 1 } : review)),
    )
    toast({
      title: "Đã thích!",
      description: "Cảm ơn bạn đã đánh giá hữu ích.",
    })
  }

  const categories = [
    "Tất cả",
    "Chương trình đào tạo",
    "Cơ sở vật chất",
    "Giảng viên",
    "Hoạt động sinh viên",
    "Hỗ trợ việc làm",
    "Khác",
  ]

  const renderStars = (rating: number, interactive = false, onSelect?: (rating: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 ${
              star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300 dark:text-gray-600"
            } ${interactive ? "cursor-pointer hover:scale-110 transition-transform" : ""}`}
            onClick={() => interactive && onSelect && onSelect(star)}
          />
        ))}
      </div>
    )
  }

  const satisfactionRate =
    stats && stats.total_reviews > 0
      ? Math.round(
          (((stats.rating_distribution?.["5"] || 0) + (stats.rating_distribution?.["4"] || 0)) / stats.total_reviews) *
            100,
        )
      : null

  if (dataSource === "none") {
    return (
      <div className="space-y-6">
        <CSVDataManager onDataProcessed={fetchReviews} />

        <Card className="p-12 text-center bg-gradient-to-br from-muted/50 to-background border-2 border-dashed">
          <div className="flex flex-col items-center gap-4 max-w-md mx-auto">
            <div className="p-4 bg-primary/10 rounded-full">
              <Upload className="h-12 w-12 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-xl text-foreground mb-2">Chưa có dữ liệu đánh giá</h3>
              <p className="text-muted-foreground leading-relaxed">
                Vui lòng nhấn nút <span className="font-semibold">"Xử lý dữ liệu CSV"</span> ở trên để tải và hiển thị
                dữ liệu đánh giá từ file CSV.
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
              <AlertCircle className="h-4 w-4" />
              <span>File CSV phải chứa: name, rating, comment, date, department, verified</span>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <CSVDataManager onDataProcessed={fetchReviews} />

      {dataSource === "csv" && reviews.length > 0 && (
        <Card className="p-4 bg-gradient-to-r from-green-500/10 to-green-500/5 border-green-200 dark:border-green-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Đang hiển thị dữ liệu thực từ CSV</h3>
                <p className="text-sm text-muted-foreground">{reviews.length} đánh giá đã được tải từ file CSV</p>
              </div>
            </div>
            <Badge variant="default" className="bg-green-600">
              Dữ liệu CSV
            </Badge>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Star className="h-6 w-6 text-primary" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {stats?.average_rating ? stats.average_rating.toFixed(1) : "-"}
              </div>
              <div className="text-sm text-muted-foreground">Đánh giá TB</div>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-secondary/10 to-secondary/5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-secondary/10 rounded-lg">
              <MessageSquare className="h-6 w-6 text-secondary" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">{stats?.total_reviews || 0}</div>
              <div className="text-sm text-muted-foreground">Đánh giá</div>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-green-500/10 to-green-500/5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/10 rounded-lg">
              <ThumbsUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {satisfactionRate !== null ? `${satisfactionRate}%` : "-"}
              </div>
              <div className="text-sm text-muted-foreground">Hài lòng</div>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-blue-500/10 to-blue-500/5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <TrendingUp className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">{stats?.verified_count || 0}</div>
              <div className="text-sm text-muted-foreground">Xác thực</div>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 bg-gradient-to-r from-accent to-accent/50">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-lg text-foreground mb-1">Chia sẻ trải nghiệm của bạn</h3>
            <p className="text-muted-foreground">Giúp các bạn sinh viên khác có thêm thông tin hữu ích</p>
          </div>
          <Button onClick={() => setShowForm(!showForm)} className="bg-secondary hover:bg-secondary/90 shrink-0">
            {showForm ? "Đóng" : "Viết đánh giá"}
          </Button>
        </div>
      </Card>

      {showForm && (
        <Card className="p-6 bg-card shadow-lg">
          <h3 className="font-bold text-xl mb-4 text-foreground">Đánh giá mới</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Đánh giá</label>
              {renderStars(newReview.rating, true, (rating) => setNewReview({ ...newReview, rating }))}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Danh mục</label>
              <select
                value={newReview.category}
                onChange={(e) => setNewReview({ ...newReview, category: e.target.value })}
                className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary bg-background"
              >
                {categories.slice(1).map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Tiêu đề</label>
              <input
                type="text"
                value={newReview.title}
                onChange={(e) => setNewReview({ ...newReview, title: e.target.value })}
                placeholder="Nhập tiêu đề đánh giá..."
                className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary bg-background"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Nội dung</label>
              <Textarea
                value={newReview.content}
                onChange={(e) => setNewReview({ ...newReview, content: e.target.value })}
                placeholder="Chia sẻ trải nghiệm của bạn..."
                rows={5}
                className="bg-background"
              />
            </div>
            <Button
              onClick={handleSubmitReview}
              className="w-full bg-primary hover:bg-primary/90"
              disabled={submitting}
            >
              {submitting ? "Đang gửi..." : "Gửi đánh giá"}
            </Button>
          </div>
        </Card>
      )}

      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            onClick={() => setSelectedCategory(category)}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            className={selectedCategory === category ? "bg-primary" : ""}
          >
            {category}
          </Button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="p-6">
              <div className="flex gap-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-20 w-full" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <Card className="p-12 text-center bg-card">
          <p className="text-muted-foreground">Chưa có đánh giá nào trong danh mục này</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id} className="p-6 hover:shadow-lg transition-shadow bg-card border-border">
              <div className="flex gap-4">
                <Avatar className="h-14 w-14 shrink-0 text-lg font-semibold">
                  <AvatarFallback
                    className={`bg-gradient-to-br ${review.avatarColor || "from-primary to-primary/70"} text-white`}
                  >
                    {review.avatar}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-bold text-lg text-foreground">{review.author}</h4>
                        {review.helpful && (
                          <Badge variant="outline" className="text-green-600 border-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Xác thực
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {review.major} - {review.year}
                      </p>
                    </div>
                    <div className="flex flex-col items-start lg:items-end gap-2">
                      <div className="flex items-center gap-2">
                        {renderStars(review.rating)}
                        <span className="text-sm font-semibold text-foreground ml-1">{review.rating}.0</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {review.category}
                      </Badge>
                    </div>
                  </div>

                  <h3 className="font-semibold text-base mb-2 text-foreground">{review.title}</h3>
                  <p className="text-muted-foreground leading-relaxed mb-4 whitespace-pre-wrap">{review.content}</p>

                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="h-4 w-4" />
                        <span>{review.date}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="hover:text-primary h-auto py-1"
                        onClick={() => handleLike(review.id)}
                      >
                        <ThumbsUp className="h-4 w-4 mr-1.5" />
                        <span>Hữu ích ({review.likes})</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="hover:text-primary h-auto py-1">
                        <MessageSquare className="h-4 w-4 mr-1.5" />
                        <span>Bình luận ({review.comments})</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
