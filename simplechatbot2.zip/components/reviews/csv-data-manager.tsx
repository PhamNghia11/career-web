"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Database, RefreshCw, CheckCircle, AlertCircle, BarChart3 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { StatisticsModal } from "./statistics-modal"

interface CSVDataManagerProps {
  onDataProcessed?: () => void
}

export function CSVDataManager({ onDataProcessed }: CSVDataManagerProps) {
  const [processing, setProcessing] = useState(false)
  const [lastProcessed, setLastProcessed] = useState<string | null>(null)
  const [stats, setStats] = useState<any>(null)
  const [showStatsModal, setShowStatsModal] = useState(false)
  const { toast } = useToast()

  const processCSVData = async () => {
    setProcessing(true)
    try {
      const response = await fetch("/api/reviews/process-csv", {
        method: "POST",
      })
      const data = await response.json()

      if (data.success) {
        toast({
          title: "Thành công!",
          description: "Dữ liệu CSV đã được xử lý và cập nhật.",
        })
        setLastProcessed(new Date().toLocaleString("vi-VN"))
        await fetchStats()
        if (onDataProcessed) {
          onDataProcessed()
        }
      } else {
        throw new Error(data.error)
      }
    } catch (error: any) {
      console.error("[v0] CSV processing error:", error)
      toast({
        title: "Lỗi",
        description: "Không thể xử lý dữ liệu CSV. Vui lòng kiểm tra file.",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/reviews/stats")
      const data = await response.json()
      if (data.success) {
        setStats(data.stats)
      }
    } catch (error) {
      console.error("[v0] Stats fetch error:", error)
    }
  }

  const handleViewStats = async () => {
    await fetchStats()
    setShowStatsModal(true)
  }

  return (
    <>
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-2 border-blue-200 dark:border-blue-800">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-500 rounded-lg">
              <Database className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-foreground">Quản lý dữ liệu CSV</h3>
              <p className="text-sm text-muted-foreground">Xử lý và hiển thị dữ liệu từ file CSV</p>
            </div>
          </div>
          <Badge variant={lastProcessed ? "default" : "secondary"} className="gap-1">
            {lastProcessed ? (
              <>
                <CheckCircle className="h-3 w-3" />
                Đã kết nối
              </>
            ) : (
              <>
                <AlertCircle className="h-3 w-3" />
                Chưa xử lý
              </>
            )}
          </Badge>
        </div>

        {stats && stats.total_reviews > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-primary">{stats.total_reviews}</div>
              <div className="text-xs text-muted-foreground">Đánh giá</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {stats.average_rating ? stats.average_rating.toFixed(1) : "0.0"}
              </div>
              <div className="text-xs text-muted-foreground">Trung bình</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.verified_count}</div>
              <div className="text-xs text-muted-foreground">Xác thực</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-blue-600">{Object.keys(stats.department_stats || {}).length}</div>
              <div className="text-xs text-muted-foreground">Khoa</div>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <Button onClick={processCSVData} disabled={processing} className="flex-1 bg-blue-600 hover:bg-blue-700">
            {processing ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Đang xử lý...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Xử lý dữ liệu CSV
              </>
            )}
          </Button>
          <Button onClick={handleViewStats} className="flex-1 bg-gradient-to-r from-primary to-secondary">
            <BarChart3 className="h-4 w-4 mr-2" />
            Xem thống kê
          </Button>
        </div>

        {lastProcessed && (
          <div className="mt-4 pt-4 border-t border-blue-200 dark:border-blue-800">
            <p className="text-xs text-muted-foreground">
              Lần cập nhật cuối: <span className="font-medium text-foreground">{lastProcessed}</span>
            </p>
          </div>
        )}

        <div className="mt-4 pt-4 border-t border-blue-200 dark:border-blue-800">
          <p className="text-xs text-muted-foreground">
            <strong>Đường dẫn CSV:</strong>{" "}
            <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">data/reviews.csv</code>
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            <strong>Format:</strong> name, rating, comment, date, department, verified
          </p>
        </div>
      </Card>

      <StatisticsModal open={showStatsModal} onOpenChange={setShowStatsModal} stats={stats} />
    </>
  )
}
