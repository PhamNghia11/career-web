import { Card } from "@/components/ui/card"

const partners = [
  { name: "FPT Software", logo: "/fpt-software-logo-black-square.jpg" },
  { name: "Vingroup", logo: "/vingroup-logo-red.jpg" },
  { name: "VNG", logo: "/vng-gaming-technology-company-logo.jpg" },
  { name: "Techcombank", logo: "/techcombank-bank-logo-blue.jpg" },
  { name: "Viettel", logo: "/viettel-telecommunications-company-logo.jpg" },
  { name: "Samsung", logo: "/samsung-electronics-vietnam-logo.jpg" },
]

export function PartnersSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-background via-muted/30 to-accent/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Doanh nghiệp đối tác</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Hợp tác cùng các doanh nghiệp hàng đầu để mang đến cơ hội việc làm tốt nhất cho sinh viên GDU
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 items-center">
          {partners.map((partner, index) => (
            <Card
              key={index}
              className="flex items-center justify-center p-6 hover:shadow-lg transition-all bg-card/80 backdrop-blur-sm border-border/50 h-24"
            >
              <img
                src={partner.logo || "/placeholder.svg"}
                alt={partner.name}
                className="max-h-12 max-w-full object-contain grayscale hover:grayscale-0 transition-all opacity-70 hover:opacity-100"
              />
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
