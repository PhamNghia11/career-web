import { MapPin, Clock, DollarSign, Building, ArrowRight } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const featuredJobs = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "FPT Software",
    location: "Quận 7, TP.HCM",
    type: "internship",
    salary: "5-8 triệu",
    deadline: "30/12/2025",
    logo: "/fpt-software-logo-black-square.jpg",
  },
  {
    id: "2",
    title: "Marketing Executive",
    company: "Vingroup",
    location: "Quận 1, TP.HCM",
    type: "full-time",
    salary: "10-15 triệu",
    deadline: "25/12/2025",
    logo: "/vingroup-logo-red.jpg",
  },
  {
    id: "3",
    title: "Business Analyst",
    company: "Techcombank",
    location: "Quận 3, TP.HCM",
    type: "full-time",
    salary: "15-20 triệu",
    deadline: "28/12/2025",
    logo: "/techcombank-bank-logo-blue.jpg",
  },
  {
    id: "4",
    title: "Graphic Designer",
    company: "VNG Corporation",
    location: "Quận Tân Bình, TP.HCM",
    type: "part-time",
    salary: "8-12 triệu",
    deadline: "31/12/2025",
    logo: "/vng-gaming-logo.jpg",
  },
]

const typeColors = {
  "full-time": "bg-green-500/20 text-green-700 border border-green-500/30",
  "part-time": "bg-blue-500/20 text-blue-700 border border-blue-500/30",
  internship: "bg-orange-500/20 text-orange-700 border border-orange-500/30",
  freelance: "bg-purple-500/20 text-purple-700 border border-purple-500/30",
}

const typeLabels = {
  "full-time": "Toàn thời gian",
  "part-time": "Bán thời gian",
  internship: "Thực tập",
  freelance: "Freelance",
}

export function FeaturedJobs() {
  return (
    <section className="py-16 bg-gradient-to-b from-accent/30 via-muted/40 to-background">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">Việc làm nổi bật</h2>
            <p className="text-muted-foreground mt-2">Cơ hội việc làm hấp dẫn dành cho sinh viên GDU</p>
          </div>
          <Link href="/jobs">
            <Button variant="outline" className="hidden md:flex items-center gap-2 bg-card hover:bg-accent">
              Xem tất cả <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredJobs.map((job) => (
            <Card key={job.id} className="hover:shadow-xl transition-all bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-start gap-4 mb-4">
                  <img
                    src={job.logo || "/placeholder.svg"}
                    alt={job.company}
                    className="w-14 h-14 rounded-lg object-cover border"
                  />
                  <div className="flex-1 min-w-0">
                    <Badge className={typeColors[job.type as keyof typeof typeColors]}>
                      {typeLabels[job.type as keyof typeof typeLabels]}
                    </Badge>
                  </div>
                </div>
                <h3 className="font-semibold text-lg mb-2 line-clamp-2 text-foreground">{job.title}</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-primary" />
                    <span className="truncate">{job.company}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="truncate">{job.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    <span className="font-medium text-foreground">{job.salary}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-secondary" />
                    <span>Hạn: {job.deadline}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button className="w-full bg-primary hover:bg-primary/90">Ứng tuyển ngay</Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <Link href="/jobs">
            <Button variant="outline" className="items-center gap-2 bg-card hover:bg-accent">
              Xem tất cả <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
