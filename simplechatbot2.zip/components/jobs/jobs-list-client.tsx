"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Search, MapPin, DollarSign, Clock, Building, Filter, Bookmark } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

const allJobs = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "FPT Software",
    location: "Quan 7, TP.HCM",
    type: "internship",
    salary: "5-8 trieu",
    deadline: "30/12/2025",
    description: "Tuyen thuc tap sinh Frontend Developer lam viec voi React, TypeScript",
  },
  {
    id: "2",
    title: "Marketing Executive",
    company: "Vingroup",
    location: "Quan 1, TP.HCM",
    type: "full-time",
    salary: "10-15 trieu",
    deadline: "25/12/2025",
    description: "Tuyen nhan vien Marketing phu trach Digital Marketing",
  },
  {
    id: "3",
    title: "Business Analyst",
    company: "Techcombank",
    location: "Quan 3, TP.HCM",
    type: "full-time",
    salary: "15-20 trieu",
    deadline: "28/12/2025",
    description: "Phan tich nghiep vu va toi uu hoa quy trinh",
  },
  {
    id: "4",
    title: "Graphic Designer",
    company: "VNG Corporation",
    location: "Quan Tan Binh, TP.HCM",
    type: "part-time",
    salary: "8-12 trieu",
    deadline: "31/12/2025",
    description: "Thiet ke do hoa cho san pham game va ung dung",
  },
  {
    id: "5",
    title: "Data Analyst Intern",
    company: "Shopee",
    location: "Quan 1, TP.HCM",
    type: "internship",
    salary: "6-10 trieu",
    deadline: "20/12/2025",
    description: "Phan tich du lieu va xay dung bao cao",
  },
  {
    id: "6",
    title: "Content Writer",
    company: "Tiki",
    location: "Quan 7, TP.HCM",
    type: "full-time",
    salary: "8-12 trieu",
    deadline: "22/12/2025",
    description: "Viet noi dung cho website va social media",
  },
]

const typeColors = {
  "full-time": "bg-green-500/20 text-green-700 border border-green-500/30",
  "part-time": "bg-blue-500/20 text-blue-700 border border-blue-500/30",
  internship: "bg-orange-500/20 text-orange-700 border border-orange-500/30",
  freelance: "bg-purple-500/20 text-purple-700 border border-purple-500/30",
}

const typeLabels = {
  "full-time": "Toan thoi gian",
  "part-time": "Ban thoi gian",
  internship: "Thuc tap",
  freelance: "Freelance",
}

export function JobsListClient() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "")
  const [typeFilter, setTypeFilter] = useState(searchParams.get("type") || "all")
  const [showFilters, setShowFilters] = useState(false)
  const [savedJobs, setSavedJobs] = useState<string[]>([])

  const filteredJobs = allJobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || job.type === typeFilter
    return matchesSearch && matchesType
  })

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (searchQuery) params.append("search", searchQuery)
    if (typeFilter !== "all") params.append("type", typeFilter)
    router.push(`/jobs?${params.toString()}`)
  }

  const handleApply = (jobId: string, jobTitle: string) => {
    console.log("[v0] Applying to job:", jobId)
    toast({
      title: "Ứng tuyển thành công!",
      description: `Bạn đã ứng tuyển vào vị trí: ${jobTitle}`,
    })
  }

  const handleSave = (jobId: string, jobTitle: string) => {
    if (savedJobs.includes(jobId)) {
      setSavedJobs(savedJobs.filter((id) => id !== jobId))
      toast({
        title: "Đã bỏ lưu",
        description: `Đã xóa ${jobTitle} khỏi danh sách lưu`,
      })
    } else {
      setSavedJobs([...savedJobs, jobId])
      toast({
        title: "Đã lưu!",
        description: `Đã lưu ${jobTitle} vào danh sách của bạn`,
      })
    }
  }

  return (
    <div>
      {/* Search & Filters */}
      <Card className="mb-6 bg-card/80 backdrop-blur-sm shadow-md border-border/50">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                placeholder="Tim kiem viec lam, cong ty..."
                className="w-full pl-10 pr-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
              >
                <option value="all">Tat ca loai</option>
                <option value="full-time">Toan thoi gian</option>
                <option value="part-time">Ban thoi gian</option>
                <option value="internship">Thuc tap</option>
              </select>
              <Button
                variant="outline"
                className="lg:hidden bg-card hover:bg-accent"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-5 w-5" />
              </Button>
              <Button onClick={handleSearch} className="hidden lg:flex bg-primary hover:bg-primary/90">
                Tim kiem
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="mb-4 text-sm text-muted-foreground">Tim thay {filteredJobs.length} viec lam phu hop</div>

      {/* Jobs List */}
      <div className="space-y-4">
        {filteredJobs.map((job) => (
          <Card key={job.id} className="hover:shadow-xl transition-all bg-card/80 backdrop-blur-sm border-border/50">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center flex-shrink-0 border border-primary/20">
                      <Building className="h-7 w-7 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="font-semibold text-lg text-foreground">{job.title}</h3>
                        <Badge className={typeColors[job.type as keyof typeof typeColors]}>
                          {typeLabels[job.type as keyof typeof typeLabels]}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground mb-2">{job.company}</p>
                      <p className="text-sm text-foreground/80 mb-3">{job.description}</p>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4 text-primary" />
                          {job.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4 text-green-600" />
                          <span className="font-medium text-foreground">{job.salary}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-secondary" />
                          Han: {job.deadline}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex lg:flex-col gap-2">
                  <Button
                    onClick={() => handleApply(job.id, job.title)}
                    className="flex-1 lg:flex-none bg-primary hover:bg-primary/90"
                  >
                    Ung tuyen ngay
                  </Button>
                  <Button
                    onClick={() => handleSave(job.id, job.title)}
                    variant="outline"
                    className="flex-1 lg:flex-none bg-card hover:bg-accent"
                  >
                    <Bookmark className={`h-4 w-4 mr-1 ${savedJobs.includes(job.id) ? "fill-current" : ""}`} />
                    Luu
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <Card className="bg-card/80 backdrop-blur-sm border-border/50">
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground">Khong tim thay viec lam phu hop. Thu thay doi bo loc.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
