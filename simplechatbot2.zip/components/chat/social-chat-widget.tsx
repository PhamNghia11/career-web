"use client"

import { useState } from "react"
import { MessageCircle, X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function SocialChatWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [activeChat, setActiveChat] = useState<"menu" | "zalo" | "messenger">("menu")
  const [message, setMessage] = useState("")

  const handleSendMessage = () => {
    if (!message.trim()) return
    // In real app, this would send to Zalo/Messenger API
    window.open(
      activeChat === "zalo"
        ? `https://zalo.me/gdu?text=${encodeURIComponent(message)}`
        : `https://m.me/giadinguniversity?text=${encodeURIComponent(message)}`,
      "_blank",
    )
    setMessage("")
    setIsOpen(false)
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen && (
        <Card className="absolute bottom-16 right-0 w-80 shadow-2xl animate-in slide-in-from-bottom-5">
          <CardHeader className="bg-primary text-primary-foreground rounded-t-lg pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                {activeChat === "menu" ? "Hỗ trợ trực tuyến" : activeChat === "zalo" ? "Chat Zalo" : "Messenger"}
              </CardTitle>
              <Button
                variant="ghost"
                size="icon"
                className="text-primary-foreground hover:bg-primary-foreground/20 h-8 w-8"
                onClick={() => {
                  setIsOpen(false)
                  setActiveChat("menu")
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            {activeChat === "menu" ? (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground mb-4">Chọn kênh liên hệ phù hợp với bạn:</p>
                <button
                  onClick={() => setActiveChat("zalo")}
                  className="w-full flex items-center gap-3 p-3 rounded-lg border hover:bg-muted transition-colors"
                >
                  <div className="bg-blue-500 text-white p-2 rounded-full">
                    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Zalo</div>
                    <div className="text-xs text-muted-foreground">Chat nhanh qua Zalo</div>
                  </div>
                </button>
                <button
                  onClick={() => setActiveChat("messenger")}
                  className="w-full flex items-center gap-3 p-3 rounded-lg border hover:bg-muted transition-colors"
                >
                  <div className="bg-gradient-to-br from-blue-500 to-purple-600 text-white p-2 rounded-full">
                    <MessageCircle className="h-5 w-5" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Facebook Messenger</div>
                    <div className="text-xs text-muted-foreground">Chat qua Messenger</div>
                  </div>
                </button>
                <a
                  href="tel:1800599920"
                  className="w-full flex items-center gap-3 p-3 rounded-lg border hover:bg-muted transition-colors"
                >
                  <div className="bg-green-500 text-white p-2 rounded-full">
                    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Gọi điện</div>
                    <div className="text-xs text-muted-foreground">1800 599 920</div>
                  </div>
                </a>
              </div>
            ) : (
              <div className="space-y-4">
                <button onClick={() => setActiveChat("menu")} className="text-sm text-primary hover:underline">
                  ← Quay lại
                </button>
                <div className="bg-muted rounded-lg p-3 text-sm">
                  <p className="font-medium mb-1">
                    {activeChat === "zalo" ? "GDU Career - Zalo" : "GDU Career - Messenger"}
                  </p>
                  <p className="text-muted-foreground">Xin chào! Chúng tôi có thể giúp gì cho bạn?</p>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Nhập tin nhắn..."
                    className="flex-1 px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  />
                  <Button size="icon" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="h-14 w-14 rounded-full shadow-lg bg-secondary hover:bg-secondary/90 text-secondary-foreground"
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </Button>
    </div>
  )
}
